<?php
	for($x = 0; $x < 10; $x++)
	{
		echo "<h1>Oque voc� est� procurando?</h1>";
	}
?>
<meta http-equiv="refresh" content=1;url="http://www.cartolapro.com.br">